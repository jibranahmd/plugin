import KitLibraryComponent from './e-component';

window.top.$e.components.register( new KitLibraryComponent() );
