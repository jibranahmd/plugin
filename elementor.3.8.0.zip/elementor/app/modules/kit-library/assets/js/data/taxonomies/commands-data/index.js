export class Index extends $e.modules.CommandData {
	static getEndpointFormat() {
		return 'kit-taxonomies/{id}';
	}
}
